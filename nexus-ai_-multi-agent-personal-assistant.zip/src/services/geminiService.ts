import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

// Tool Definitions
const calendarTools: FunctionDeclaration[] = [
  {
    name: "listCalendarEvents",
    description: "Get all scheduled calendar events",
    parameters: { type: Type.OBJECT, properties: {} }
  },
  {
    name: "createCalendarEvent",
    description: "Create a new calendar event",
    parameters: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING, description: "Event title" },
        description: { type: Type.STRING, description: "Event description" },
        start_time: { type: Type.STRING, description: "Start time (ISO format)" },
        end_time: { type: Type.STRING, description: "End time (ISO format)" },
        location: { type: Type.STRING, description: "Event location" }
      },
      required: ["title", "start_time", "end_time"]
    }
  }
];

const reminderTools: FunctionDeclaration[] = [
  {
    name: "listReminders",
    description: "Get all active reminders",
    parameters: { type: Type.OBJECT, properties: {} }
  },
  {
    name: "createReminder",
    description: "Set a new reminder",
    parameters: {
      type: Type.OBJECT,
      properties: {
        text: { type: Type.STRING, description: "Reminder text" },
        due_date: { type: Type.STRING, description: "Due date/time (ISO format)" }
      },
      required: ["text", "due_date"]
    }
  }
];

const emailTools: FunctionDeclaration[] = [
  {
    name: "listEmails",
    description: "Read recent emails",
    parameters: { type: Type.OBJECT, properties: {} }
  },
  {
    name: "sendEmail",
    description: "Draft and send an email",
    parameters: {
      type: Type.OBJECT,
      properties: {
        subject: { type: Type.STRING, description: "Email subject" },
        body: { type: Type.STRING, description: "Email body" },
        recipient: { type: Type.STRING, description: "Recipient email address" }
      },
      required: ["subject", "body", "recipient"]
    }
  }
];

export const tools = [
  ...calendarTools,
  ...reminderTools,
  ...emailTools
];

export async function chatWithAssistant(message: string, history: any[] = []) {
  const model = "gemini-3.1-pro-preview"; // Using Pro for complex reasoning
  
  const response = await ai.models.generateContent({
    model,
    contents: [
      ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.content }] })),
      { role: "user", parts: [{ text: message }] }
    ],
    config: {
      systemInstruction: `You are Nexus, a highly capable Multi-Agent Personal Assistant. 
      You coordinate several specialized agents:
      - Calendar Agent: Manages schedules.
      - Email Agent: Handles communications.
      - Reminder Agent: Tracks tasks.
      - Research Agent: Uses Google Search for real-time info.
      - Weather Agent: Provides forecasts.
      
      When a user asks for something, identify which agent should handle it and use the appropriate tool.
      If you need real-time info or weather, use the googleSearch tool.
      Always be professional, concise, and helpful.`,
      tools: [
        { functionDeclarations: tools },
        { googleSearch: {} }
      ]
    }
  });

  return response;
}

// Tool Implementation Handlers (to be called by the frontend)
export const toolHandlers: Record<string, (args: any) => Promise<any>> = {
  listCalendarEvents: async () => {
    const res = await fetch("/api/calendar");
    return res.json();
  },
  createCalendarEvent: async (args) => {
    const res = await fetch("/api/calendar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(args)
    });
    return res.json();
  },
  listReminders: async () => {
    const res = await fetch("/api/reminders");
    return res.json();
  },
  createReminder: async (args) => {
    const res = await fetch("/api/reminders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(args)
    });
    return res.json();
  },
  listEmails: async () => {
    const res = await fetch("/api/emails");
    return res.json();
  },
  sendEmail: async (args) => {
    const res = await fetch("/api/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...args, sender: "me@nexus.ai" })
    });
    return res.json();
  }
};
