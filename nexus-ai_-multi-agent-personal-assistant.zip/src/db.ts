import Database from 'better-sqlite3';
import { join } from 'path';

const db = new Database('assistant.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    due_date TEXT NOT NULL,
    completed INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS calendar_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    location TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    sender TEXT NOT NULL,
    recipient TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS preferences (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS chat_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Initial Demo Data
  INSERT INTO calendar_events (title, description, start_time, end_time, location) 
  SELECT 'Product Strategy Sync', 'Discuss Q3 roadmap and agent performance.', '2026-02-23T10:00:00', '2026-02-23T11:00:00', 'Virtual / Zoom'
  WHERE NOT EXISTS (SELECT 1 FROM calendar_events);

  INSERT INTO reminders (text, due_date)
  SELECT 'Review design specs for Nexus v2', '2026-02-22T18:00:00'
  WHERE NOT EXISTS (SELECT 1 FROM reminders);

  INSERT INTO emails (subject, body, sender, recipient)
  SELECT 'Welcome to Nexus AI', 'Hello! I am your new personal assistant. How can I help you today?', 'system@nexus.ai', 'user@example.com'
  WHERE NOT EXISTS (SELECT 1 FROM emails);
`);

export default db;
