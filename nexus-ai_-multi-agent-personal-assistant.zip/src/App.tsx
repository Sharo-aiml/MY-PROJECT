import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  MessageSquare, 
  Calendar, 
  Mail, 
  Bell, 
  Search, 
  Cloud, 
  Settings, 
  Mic, 
  MicOff, 
  Send,
  LayoutDashboard,
  ChevronRight,
  User,
  Bot,
  Loader2
} from 'lucide-react';
import { chatWithAssistant, toolHandlers } from './services/geminiService';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import Markdown from 'react-markdown';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'error';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'chat' | 'dashboard' | 'calendar' | 'emails' | 'reminders'>('chat');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Load initial chat history
    fetch('/api/chat')
      .then(res => res.json())
      .then(data => {
        setMessages(data.map((m: any) => ({
          id: m.id.toString(),
          role: m.role === 'user' ? 'user' : 'assistant',
          content: m.content,
          timestamp: new Date(m.timestamp)
        })));
      });
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (text: string = input) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
      status: 'sending'
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      // Save user message to DB
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'user', content: text })
      });

      const response = await chatWithAssistant(text, messages);
      
      let finalContent = "";
      
      // Handle Function Calls
      if (response.functionCalls) {
        for (const call of response.functionCalls) {
          const handler = toolHandlers[call.name];
          if (handler) {
            const result = await handler(call.args);
            finalContent += `[Action: ${call.name}] Result: ${JSON.stringify(result)}\n\n`;
          }
        }
      }

      finalContent += response.text || "I've processed your request.";

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: finalContent,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      // Save assistant message to DB
      await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'assistant', content: finalContent })
      });

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: "Sorry, I encountered an error. Please check your API key and connection.",
        timestamp: new Date(),
        status: 'error'
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  const toggleListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert("Speech recognition not supported in this browser.");
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    if (!isListening) {
      recognition.start();
      setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleSend(transcript);
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
    } else {
      recognition.stop();
      setIsListening(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-indigo-100">
      {/* Sidebar */}
      <aside className="w-64 border-r border-gray-200 bg-white flex flex-col">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <Bot size={24} />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight">Nexus AI</h1>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">Multi-Agent</p>
            </div>
          </div>

          <nav className="space-y-1">
            <NavItem 
              icon={<MessageSquare size={20} />} 
              label="Chat Assistant" 
              active={activeTab === 'chat'} 
              onClick={() => setActiveTab('chat')} 
            />
            <NavItem 
              icon={<LayoutDashboard size={20} />} 
              label="Dashboard" 
              active={activeTab === 'dashboard'} 
              onClick={() => setActiveTab('dashboard')} 
            />
            <div className="pt-4 pb-2 px-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Specialists</div>
            <NavItem 
              icon={<Calendar size={20} />} 
              label="Calendar" 
              active={activeTab === 'calendar'} 
              onClick={() => setActiveTab('calendar')} 
            />
            <NavItem 
              icon={<Mail size={20} />} 
              label="Emails" 
              active={activeTab === 'emails'} 
              onClick={() => setActiveTab('emails')} 
            />
            <NavItem 
              icon={<Bell size={20} />} 
              label="Reminders" 
              active={activeTab === 'reminders'} 
              onClick={() => setActiveTab('reminders')} 
            />
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-gray-100">
          <div className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors">
            <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
              <User size={18} className="text-gray-600" />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-semibold truncate">User Profile</p>
              <p className="text-xs text-gray-500 truncate">Settings & Preferences</p>
            </div>
            <Settings size={16} className="text-gray-400" />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {activeTab === 'chat' ? (
          <>
            {/* Chat Header */}
            <header className="h-16 border-b border-gray-100 bg-white/80 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-10">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="text-sm font-medium text-gray-600">Coordinator Agent Online</span>
              </div>
              <div className="flex items-center gap-4">
                <button className="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
                  <Search size={20} />
                </button>
                <div className="h-4 w-[1px] bg-gray-200" />
                <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
                  <Cloud size={18} />
                  <span>72°F</span>
                </div>
              </div>
            </header>

            {/* Messages Area */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-8 space-y-6 scroll-smooth"
            >
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-4">
                  <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 mb-2">
                    <Bot size={32} />
                  </div>
                  <h2 className="text-2xl font-bold tracking-tight">How can I help you today?</h2>
                  <p className="text-gray-500 leading-relaxed">
                    I'm your Nexus AI assistant. I can manage your calendar, draft emails, set reminders, and research any topic for you.
                  </p>
                  <div className="grid grid-cols-2 gap-3 w-full pt-4">
                    <SuggestionCard text="Schedule a meeting" onClick={() => setInput("Schedule a meeting for tomorrow at 10am")} />
                    <SuggestionCard text="Check my emails" onClick={() => setInput("Show me my recent emails")} />
                    <SuggestionCard text="Set a reminder" onClick={() => setInput("Remind me to call Mom at 6pm")} />
                    <SuggestionCard text="Search AI news" onClick={() => setInput("What's the latest news in AI?")} />
                  </div>
                </div>
              )}

              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex gap-4 max-w-3xl",
                    msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-1",
                    msg.role === 'user' ? "bg-gray-100 text-gray-600" : "bg-indigo-600 text-white"
                  )}>
                    {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                  </div>
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed shadow-sm",
                    msg.role === 'user' 
                      ? "bg-indigo-600 text-white rounded-tr-none" 
                      : "bg-white border border-gray-100 rounded-tl-none"
                  )}>
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      <Markdown>{msg.content}</Markdown>
                    </div>
                    <div className={cn(
                      "text-[10px] mt-2 opacity-50",
                      msg.role === 'user' ? "text-right" : ""
                    )}>
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </motion.div>
              ))}

              {isTyping && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex gap-4 max-w-3xl"
                >
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                    <Bot size={16} />
                  </div>
                  <div className="bg-white border border-gray-100 p-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                    <Loader2 size={16} className="animate-spin text-indigo-600" />
                    <span className="text-xs font-medium text-gray-500">Nexus is thinking...</span>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Input Area */}
            <div className="p-8 pt-0">
              <div className="max-w-4xl mx-auto relative">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                  <button 
                    onClick={toggleListening}
                    className={cn(
                      "p-2 rounded-lg transition-all",
                      isListening ? "bg-red-50 text-red-600 animate-pulse" : "text-gray-400 hover:text-indigo-600 hover:bg-gray-50"
                    )}
                  >
                    {isListening ? <Mic size={20} /> : <MicOff size={20} />}
                  </button>
                </div>
                <input 
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask Nexus anything..."
                  className="w-full bg-white border border-gray-200 rounded-2xl py-4 pl-14 pr-14 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all shadow-sm"
                />
                <button 
                  onClick={() => handleSend()}
                  disabled={!input.trim() || isTyping}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-indigo-200"
                >
                  <Send size={18} />
                </button>
              </div>
              <p className="text-center text-[10px] text-gray-400 mt-4 font-medium uppercase tracking-widest">
                Nexus AI Agent v1.0 • Powered by Gemini 3.1 Pro
              </p>
            </div>
          </>
        ) : (
          <div className="flex-1 overflow-y-auto p-8">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold tracking-tight capitalize">{activeTab}</h2>
                <div className="flex items-center gap-3">
                  <button className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-colors shadow-sm">
                    Refresh
                  </button>
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200">
                    Add New
                  </button>
                </div>
              </div>
              
              {activeTab === 'dashboard' && <DashboardView />}
              {activeTab === 'calendar' && <CalendarView />}
              {activeTab === 'emails' && <EmailsView />}
              {activeTab === 'reminders' && <RemindersView />}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group",
        active 
          ? "bg-indigo-50 text-indigo-600 shadow-sm" 
          : "text-gray-500 hover:bg-gray-50 hover:text-gray-900"
      )}
    >
      <span className={cn(
        "transition-colors",
        active ? "text-indigo-600" : "text-gray-400 group-hover:text-gray-600"
      )}>
        {icon}
      </span>
      {label}
      {active && <ChevronRight size={14} className="ml-auto opacity-50" />}
    </button>
  );
}

function SuggestionCard({ text, onClick }: { text: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="p-4 bg-white border border-gray-100 rounded-2xl text-left hover:border-indigo-200 hover:shadow-md transition-all group"
    >
      <p className="text-sm font-semibold text-gray-700 group-hover:text-indigo-600 transition-colors">{text}</p>
      <div className="mt-2 flex items-center text-[10px] text-gray-400 font-bold uppercase tracking-wider">
        Try this <ChevronRight size={10} className="ml-1" />
      </div>
    </button>
  );
}

// --- Sub-Views ---

function DashboardView() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <StatCard title="Upcoming Events" value="3" subtitle="Next: Team Sync at 2 PM" icon={<Calendar className="text-blue-500" />} />
      <StatCard title="Unread Emails" value="12" subtitle="5 urgent priorities" icon={<Mail className="text-amber-500" />} />
      <StatCard title="Active Reminders" value="8" subtitle="2 due in next hour" icon={<Bell className="text-rose-500" />} />
      
      <div className="col-span-full lg:col-span-2 bg-white border border-gray-100 rounded-3xl p-8 shadow-sm">
        <h3 className="text-lg font-bold mb-6">Recent Activity</h3>
        <div className="space-y-6">
          <ActivityItem 
            title="Meeting Scheduled" 
            desc="Project Kickoff with Design Team" 
            time="10 mins ago" 
            icon={<Calendar size={16} />} 
            color="bg-blue-50 text-blue-600"
          />
          <ActivityItem 
            title="Email Sent" 
            desc="Follow-up to client regarding proposal" 
            time="45 mins ago" 
            icon={<Mail size={16} />} 
            color="bg-amber-50 text-amber-600"
          />
          <ActivityItem 
            title="Reminder Set" 
            desc="Buy groceries on the way home" 
            time="2 hours ago" 
            icon={<Bell size={16} />} 
            color="bg-rose-50 text-rose-600"
          />
        </div>
      </div>

      <div className="bg-white border border-gray-100 rounded-3xl p-8 shadow-sm">
        <h3 className="text-lg font-bold mb-6">Agent Status</h3>
        <div className="space-y-4">
          <AgentStatus name="Coordinator" status="Idle" load={12} />
          <AgentStatus name="Calendar" status="Syncing" load={45} />
          <AgentStatus name="Email" status="Idle" load={5} />
          <AgentStatus name="Research" status="Active" load={88} />
        </div>
      </div>
    </div>
  );
}

function CalendarView() {
  const [events, setEvents] = useState<any[]>([]);
  useEffect(() => {
    fetch('/api/calendar').then(res => res.json()).then(setEvents);
  }, []);

  return (
    <div className="bg-white border border-gray-100 rounded-3xl overflow-hidden shadow-sm">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-gray-50/50 border-b border-gray-100">
            <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Event</th>
            <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Time</th>
            <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Location</th>
            <th className="px-8 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {events.map(event => (
            <tr key={event.id} className="hover:bg-gray-50/50 transition-colors">
              <td className="px-8 py-5">
                <p className="font-semibold text-sm">{event.title}</p>
                <p className="text-xs text-gray-500 mt-1">{event.description}</p>
              </td>
              <td className="px-8 py-5 text-sm text-gray-600">
                {new Date(event.start_time).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </td>
              <td className="px-8 py-5 text-sm text-gray-500">{event.location || 'N/A'}</td>
              <td className="px-8 py-5">
                <span className="px-2.5 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold uppercase tracking-wider rounded-full">Confirmed</span>
              </td>
            </tr>
          ))}
          {events.length === 0 && (
            <tr>
              <td colSpan={4} className="px-8 py-12 text-center text-gray-400 italic">No events scheduled.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

function EmailsView() {
  const [emails, setEmails] = useState<any[]>([]);
  useEffect(() => {
    fetch('/api/emails').then(res => res.json()).then(setEmails);
  }, []);

  return (
    <div className="space-y-4">
      {emails.map(email => (
        <div key={email.id} className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:border-indigo-200 transition-all cursor-pointer group">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                <Mail size={20} />
              </div>
              <div>
                <h4 className="font-bold text-sm group-hover:text-indigo-600 transition-colors">{email.subject}</h4>
                <p className="text-xs text-gray-500">From: {email.sender}</p>
              </div>
            </div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              {new Date(email.sent_at).toLocaleDateString()}
            </span>
          </div>
          <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">{email.body}</p>
        </div>
      ))}
      {emails.length === 0 && (
        <div className="bg-white border border-gray-100 rounded-3xl p-12 text-center text-gray-400 italic">
          Your inbox is empty.
        </div>
      )}
    </div>
  );
}

function RemindersView() {
  const [reminders, setReminders] = useState<any[]>([]);
  useEffect(() => {
    fetch('/api/reminders').then(res => res.json()).then(setReminders);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {reminders.map(reminder => (
        <div key={reminder.id} className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm flex items-center gap-4 group">
          <button className="w-6 h-6 border-2 border-gray-200 rounded-lg flex items-center justify-center hover:border-indigo-500 transition-colors">
            <div className="w-2 h-2 bg-indigo-500 rounded-sm opacity-0 group-hover:opacity-20 transition-opacity" />
          </button>
          <div className="flex-1">
            <p className="text-sm font-semibold">{reminder.text}</p>
            <p className="text-xs text-rose-500 font-medium mt-1 flex items-center gap-1">
              <Bell size={10} />
              {new Date(reminder.due_date).toLocaleString()}
            </p>
          </div>
        </div>
      ))}
      {reminders.length === 0 && (
        <div className="col-span-full bg-white border border-gray-100 rounded-3xl p-12 text-center text-gray-400 italic">
          No active reminders.
        </div>
      )}
    </div>
  );
}

// --- Helper Components ---

function StatCard({ title, value, subtitle, icon }: { title: string, value: string, subtitle: string, icon: React.ReactNode }) {
  return (
    <div className="bg-white border border-gray-100 rounded-3xl p-8 shadow-sm hover:shadow-md transition-all">
      <div className="flex items-center justify-between mb-6">
        <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center">
          {icon}
        </div>
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Live Status</span>
      </div>
      <h4 className="text-gray-500 text-sm font-medium mb-1">{title}</h4>
      <div className="flex items-baseline gap-2 mb-2">
        <span className="text-4xl font-bold tracking-tight">{value}</span>
      </div>
      <p className="text-xs text-gray-400 font-medium">{subtitle}</p>
    </div>
  );
}

function ActivityItem({ title, desc, time, icon, color }: { title: string, desc: string, time: string, icon: React.ReactNode, color: string }) {
  return (
    <div className="flex gap-4">
      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", color)}>
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between mb-1">
          <h5 className="text-sm font-bold">{title}</h5>
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{time}</span>
        </div>
        <p className="text-xs text-gray-500 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

function AgentStatus({ name, status, load }: { name: string, status: string, load: number }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest">
        <span className="text-gray-500">{name} Agent</span>
        <span className={cn(
          status === 'Active' ? "text-emerald-600" : "text-gray-400"
        )}>{status}</span>
      </div>
      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${load}%` }}
          className={cn(
            "h-full rounded-full",
            load > 80 ? "bg-rose-500" : load > 40 ? "bg-amber-500" : "bg-indigo-500"
          )}
        />
      </div>
    </div>
  );
}
