import express from "express";
import { createServer as createViteServer } from "vite";
import db from "./src/db.ts";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Routes ---

  // Reminders
  app.get("/api/reminders", (req, res) => {
    const reminders = db.prepare("SELECT * FROM reminders ORDER BY due_date ASC").all();
    res.json(reminders);
  });

  app.post("/api/reminders", (req, res) => {
    const { text, due_date } = req.body;
    const info = db.prepare("INSERT INTO reminders (text, due_date) VALUES (?, ?)").run(text, due_date);
    res.json({ id: info.lastInsertRowid, text, due_date });
  });

  app.delete("/api/reminders/:id", (req, res) => {
    db.prepare("DELETE FROM reminders WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Calendar
  app.get("/api/calendar", (req, res) => {
    const events = db.prepare("SELECT * FROM calendar_events ORDER BY start_time ASC").all();
    res.json(events);
  });

  app.post("/api/calendar", (req, res) => {
    const { title, description, start_time, end_time, location } = req.body;
    const info = db.prepare("INSERT INTO calendar_events (title, description, start_time, end_time, location) VALUES (?, ?, ?, ?, ?)").run(title, description, start_time, end_time, location);
    res.json({ id: info.lastInsertRowid, title, start_time });
  });

  // Emails
  app.get("/api/emails", (req, res) => {
    const emails = db.prepare("SELECT * FROM emails ORDER BY sent_at DESC").all();
    res.json(emails);
  });

  app.post("/api/emails", (req, res) => {
    const { subject, body, sender, recipient } = req.body;
    const info = db.prepare("INSERT INTO emails (subject, body, sender, recipient) VALUES (?, ?, ?, ?)").run(subject, body, sender, recipient);
    res.json({ id: info.lastInsertRowid, subject });
  });

  // Chat History
  app.get("/api/chat", (req, res) => {
    const history = db.prepare("SELECT * FROM chat_history ORDER BY timestamp ASC").all();
    res.json(history);
  });

  app.post("/api/chat", (req, res) => {
    const { role, content } = req.body;
    db.prepare("INSERT INTO chat_history (role, content) VALUES (?, ?)").run(role, content);
    res.json({ success: true });
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
    app.get("*", (req, res) => {
      res.sendFile("dist/index.html", { root: "." });
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
